from flask import Blueprint
from flask_restful import Api

from app.modules.budget.budget_resource import BudgetResource
from app.modules.company.company_resource import CompanyResource
from app.modules.customer.customer_resource import CustomerResource
from app.modules.file_repository.file_repository_resource import FileRepositoryResource
from app.modules.login.login_resource import LoginResource
from app.modules.permission.permission_resource import PermissionResource
from app.modules.product.product_resource import ProductResource
from app.modules.product_category.product_category_resource import ProductCategoryResource
from app.modules.product_subcategory.product_subcategory_resource import ProductSubcategoryResource
from app.modules.product_type.product_type_resource import ProductTypeResource
from app.modules.sales.sales_resource import SalesResource
from app.modules.sales_status.sales_status_resource import SalesStatusResource
from app.modules.service.service_resource import ServiceResource
from app.modules.service_type.service_type_resource import ServiceTypeResource
from app.modules.stock.stock_type_resource import StockTypeResource
from app.modules.test.test_resource import TestResource
from app.modules.user.user_resource import UserResource

api_blueprint = Blueprint('api', __name__)
api = Api(api_blueprint)


api.add_resource(TestResource, '/teste')

# FILES
api.add_resource(FileRepositoryResource, '/arquivo', '/arquivo/<string:action>')

# LOGIN
api.add_resource(LoginResource, '/login')

# PERMISSION
api.add_resource(PermissionResource, '/permissao')

# USER
api.add_resource(UserResource, '/usuarios')

# COMPANY
api.add_resource(CompanyResource, '/empresa', '/empresa/<string:action>')

# PRODUCT
api.add_resource(ProductResource, '/produto', '/produto/<string:action>')

# PRODUCT CATEGORY
api.add_resource(ProductCategoryResource, '/produto-categoria', '/produto-categoria/<string:action>')

# PRODUCT SUBCATEGORY
api.add_resource(ProductSubcategoryResource, '/produto-subcategoria', '/produto-subcategoria/<string:action>')

# PRODUCT TYPE
api.add_resource(ProductTypeResource, '/produto-tipo', '/produto-tipo/<string:action>')

# SERVICE
api.add_resource(ServiceResource, '/servico', '/servico/<string:action>')

# SERVICE TYPE
api.add_resource(ServiceTypeResource, '/servico-tipo', '/servico-tipo/<string:action>')

# STOCK TYPE
api.add_resource(StockTypeResource, '/estoque-tipo', '/estoque-tipo/<string:action>')

# BUDGET
api.add_resource(BudgetResource, '/orcamento', '/orcamento/<string:action>')

# SALES
api.add_resource(SalesResource, '/venda', '/venda/<string:action>')

# SALES STATUS
api.add_resource(SalesStatusResource, '/venda-status', '/venda-status/<string:action>')

# CUSTOMER
api.add_resource(CustomerResource, '/cliente', '/cliente/<string:action>')
